package playground;
import java.awt.Color;

import javashooter.controller.CollisionAware4WayController;
import javashooter.gameobjects.GameObject;
import spaceinvadersProject.gameobjects.EgoObject;
import spaceinvadersProject.playground.*;
import javashooter.rendering.*;

public class W10Level extends SpaceInvadersLevel {

	protected String getStartupMessage() {
	    return "W10LEVEL";
	  }
	
	protected GameObject createEgoObject() {
        // EgoController initialisieren
        CollisionAware4WayController egoController = new CollisionAware4WayController(this.calcEgoSpeed());
        egoController.setSpeed(this.calcEgoSpeed());

        // Ego-Objekt erstellen
        GameObject ego = new EgoObject("ego", this, 50, preferredSizeY() - 60, 0, 0, EGORAD)
                .setController(egoController).generateColliders();

        // PulsatingCircleArtist hinzufügen
        PulsatingCircleArtist pulsatingCircleArtist = new PulsatingCircleArtist(ego, EGORAD, Color.GREEN, 0.3, 0.1 );
        ego.addArtist(pulsatingCircleArtist);

        return ego;
    }
	
}
