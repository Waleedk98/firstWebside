package w10;
import javashooter.playground.Playground;
import spaceinvadersProject.SpaceInvadersGame;
import playground.W10Level;

public class EigenesSpielW10 extends SpaceInvadersGame{
	
	public Playground nextLevel(Playground currentLevel) {     
	    if(currentLevel == null) {
	    	currentLevel = new W10Level();
	    	return currentLevel;
	    }
	    return null;
	  }

	public static void main(String[] args) {
		EigenesSpielW10 game = new EigenesSpielW10();
		game.runGame(args);

	}

}
